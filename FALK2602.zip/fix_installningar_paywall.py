import os

print("=== OPTERAR INSTÄLLNINGAR.HTML: FLYTTAR PAYWALL TILL POPUP-MODAL ===")

installningar_html = '''<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FALK - Inställningar & Integritet</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body.theme-standard { background-color: #E8DCC4 !important; color: #38322B; }
        body.theme-dark { background-color: #1C1A17 !important; color: #E8DCC4; }
        body.theme-dark header { background-color: #1C1A17 !important; border-color: #3D3730 !important; }
        body.theme-dark header a, body.theme-dark header button { color: #E8DCC4 !important; }
        .falk-card { background-color: #FAF8F0; border: 1px solid #DDD0B8; }
        body.theme-dark .falk-card { background-color: #26231F !important; border-color: #3D3730 !important; color: #E8DCC4 !important; }
    </style>
</head>
<body class="theme-standard min-h-screen flex flex-col justify-between antialiased relative overflow-x-hidden">
    
    <!-- VÄNSTER MENY (DRAWER) -->
    <div id="falk-left-backdrop" onclick="closeLeftMenu()" class="fixed inset-0 bg-black/40 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300 z-40"></div>
    <aside id="falk-left-drawer" class="fixed top-0 left-0 h-full w-80 bg-[#FAF8F0]/95 backdrop-blur-md shadow-2xl transform -translate-x-full transition-transform duration-300 ease-in-out z-50 flex flex-col border-r border-[#DDD0B8]">
        <div class="p-6 border-b border-[#E6E0D4]/80">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-[11px] font-bold tracking-wide text-[#8C5D37] uppercase">FALK - EN KOMPASS MED PERSPEKTIV</p>
                    <h2 class="text-xl font-extrabold text-[#2D2721] mt-0.5">Meny</h2>
                </div>
                <button onclick="closeLeftMenu()" class="p-1 text-stone-600 hover:text-black rounded-lg">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
        </div>
        <nav class="flex-1 p-5 space-y-2 overflow-y-auto">
            <a href="/" class="flex items-center gap-3.5 px-4 py-3 text-sm rounded-2xl transition-all font-medium text-stone-700 hover:bg-[#E8DCC4]/40">
                <svg class="w-5 h-5 text-stone-700 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
                <span>Chatt</span>
            </a>
            <a href="/bibliotek" onclick="if(typeof IS_GUEST !== 'undefined' && IS_GUEST){ event.preventDefault(); openPaywallModal('bibliotek'); }" class="flex items-center gap-3.5 px-4 py-3 text-sm rounded-2xl transition-all font-medium text-stone-700 hover:bg-[#E8DCC4]/40">
                <svg class="w-5 h-5 text-stone-700 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                <span>Bibliotek</span>
            </a>
            <a href="/utveckling" onclick="if(typeof IS_GUEST !== 'undefined' && IS_GUEST){ event.preventDefault(); openPaywallModal('utveckling'); }" class="flex items-center gap-3.5 px-4 py-3 text-sm rounded-2xl transition-all font-medium text-stone-700 hover:bg-[#E8DCC4]/40">
                <svg class="w-5 h-5 text-stone-700 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                <span>Min utveckling</span>
            </a>
            <a href="/installningar" class="flex items-center gap-3.5 px-4 py-3 text-sm rounded-2xl transition-all bg-[#D6CDB8]/60 font-bold text-[#2D2721]">
                <svg class="w-5 h-5 text-stone-700 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                <span>Inställningar och integritet</span>
            </a>
        </nav>
        <div class="p-5 border-t border-[#E6E0D4]/80 mt-auto flex items-center justify-between">
            <span class="px-4 py-1.5 text-xs font-bold tracking-wider text-stone-800 bg-white border border-[#DDD0B8] rounded-full uppercase shadow-xs">GÄST</span>
            <button onclick="openPaywallModal('login')" class="px-6 py-2 text-xs font-bold text-white bg-[#3A352E] hover:bg-[#2D2721] rounded-full transition-all">Logga in</button>
        </div>
    </aside>

    <!-- HEADER -->
    <header class="relative flex items-center justify-between px-5 py-4 border-b border-[#D8CAB0]/80 bg-[#E8DCC4] sticky top-0 z-30">
        <div class="flex items-center gap-3 z-10">
            <button onclick="openLeftMenu()" class="p-1 text-black hover:opacity-75 transition-all focus:outline-none">
                <svg class="w-6 h-6 text-black stroke-current" fill="none" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
            <span class="px-2.5 py-0.5 text-[11px] font-bold tracking-wider text-[#8C5D37] bg-[#FAF8F0] border border-[#DDD0B8] rounded-full uppercase shadow-xs">GÄST</span>
        </div>
        <div class="absolute left-1/2 -translate-x-1/2 flex items-center">
            <a href="/" class="text-2xl font-black tracking-wider text-black hover:opacity-75 transition-all cursor-pointer">FALK</a>
        </div>
        <div class="flex items-center gap-4 z-10">
            <a href="/" class="text-black hover:opacity-75 transition-all" title="Ny chat">
                <svg class="w-5 h-5 text-black stroke-current" fill="none" stroke-width="2.2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"></path></svg>
            </a>
            <button onclick="if(typeof IS_GUEST !== 'undefined' && IS_GUEST){ openPaywallModal('right_menu'); } else { openRightMenu(); }" class="group text-black hover:opacity-100 transition-all focus:outline-none p-1">
                <svg class="w-6 h-6 text-black stroke-current fill-none relative" viewBox="0 0 24 24" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M 8.5 13 C 7 11.2 7 8 9 6 C 10.8 4.2 13.2 4.2 15 6 C 17 8 17 11.2 15.5 13 C 14.8 13.8 14.5 14.5 14.5 15.5 L 9.5 15.5 C 9.5 14.5 9.2 13.8 8.5 13 Z" />
                    <line x1="9.5" y1="18" x2="14.5" y2="18" />
                    <line x1="10.5" y1="20.5" x2="13.5" y2="20.5" />
                </svg>
            </button>
        </div>
    </header>

    <!-- INNEHÅLL (INSTÄLLNINGAR & INTEGRITET EXAKT ENLIGT SKÄRMDUMP) -->
    <main class="flex-1 max-w-2xl w-full mx-auto px-4 py-8 space-y-6">
        <div class="text-center space-y-1">
            <h1 class="text-2xl font-black text-[#2D2721]">Inställningar & integritet</h1>
            <p class="text-xs italic opacity-75 font-serif text-stone-600">Hantera dina gränssnittsval, data och kontosäkerhet</p>
        </div>

        <!-- VAL AV VY (TEMA) -->
        <div class="falk-card p-5 rounded-2xl space-y-4 shadow-xs">
            <h2 class="text-xs font-bold text-[#8C5D37] uppercase tracking-wider">VAL AV VY (TEMA)</h2>
            <div class="grid grid-cols-2 gap-3">
                <button onclick="setTheme('standard')" id="btn-theme-standard" class="py-2.5 px-4 rounded-xl text-xs font-bold transition-all border border-[#DDD0B8] bg-[#2D2721] text-white">FALK Standard</button>
                <button onclick="setTheme('dark')" id="btn-theme-dark" class="py-2.5 px-4 rounded-xl text-xs font-bold transition-all border border-[#DDD0B8] bg-white text-stone-800 hover:bg-stone-100">Mörk vy</button>
            </div>
        </div>

        <!-- DINA DATA & EXPORT -->
        <div class="falk-card p-5 rounded-2xl space-y-3 shadow-xs">
            <h2 class="text-xs font-bold text-[#8C5D37] uppercase tracking-wider">DINA DATA & EXPORT</h2>
            <p class="text-xs text-stone-600 leading-relaxed">Du äger din data. Du kan när som helst ladda ned en fullständig kopia av dina reflektioner och samtal.</p>
            <div class="pt-1">
                <!-- EXPORT-KNAPP: TRIGGAR PAYWALL FOR GÄSTER -->
                <button onclick="if(typeof IS_GUEST !== 'undefined' && IS_GUEST){ openPaywallModal('export'); } else { fetch('/api/user/export').then(r=>r.json()).then(d=>alert(JSON.stringify(d, null, 2))); }" class="px-5 py-2.5 bg-[#4E5C4B] hover:bg-[#3D493B] text-white text-xs font-bold rounded-xl transition-all inline-flex items-center gap-2 shadow-xs">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    <span>Exportera all min data (.json)</span>
                </button>
            </div>
        </div>

        <!-- VILLKOR & INTEGRITET -->
        <div class="falk-card p-5 rounded-2xl space-y-3 shadow-xs">
            <h2 class="text-xs font-bold text-[#8C5D37] uppercase tracking-wider">VILLKOR & INTEGRITET</h2>
            <div class="space-y-2 text-xs font-bold text-[#2D2721]">
                <a href="#" onclick="alert('Användarvillkor')" class="block hover:underline">Användarvillkor</a>
                <a href="#" onclick="alert('Integritetspolicy & GDPR')" class="block hover:underline">Integritetspolicy & GDPR</a>
            </div>
        </div>

        <!-- FARA / KONTOÅTGÄRDER -->
        <div class="falk-card p-5 rounded-2xl space-y-3 shadow-xs">
            <h2 class="text-xs font-bold text-[#8C5D37] uppercase tracking-wider">FARA / KONTOÅTGÄRDER</h2>
            <p class="text-xs text-stone-600 leading-relaxed">Raderar permanent hela ditt konto, dina sparade insikter och din samtalshistorik.</p>
            <div class="pt-1">
                <button onclick="if(confirm('Är du säker på att du vill radera ditt konto?')){ alert('Konto raderat'); }" class="px-5 py-2.5 bg-[#A83232] hover:bg-[#8A2828] text-white text-xs font-bold rounded-xl transition-all shadow-xs">
                    Radera mitt konto och all min data
                </button>
            </div>
        </div>
    </main>

    <!-- UNIVERSAL POPUP PAYWALL MODAL (VISAS ENDAST VID EXPORTKLICK ELLER TRIGGERS) -->
    <div id="falk-paywall-backdrop" onclick="closePaywallModal()" class="fixed inset-0 bg-black/60 backdrop-blur-md hidden opacity-0 transition-opacity duration-300 z-50"></div>
    
    <div id="falk-paywall-modal" class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92%] max-w-md bg-[#FAF8F0] border border-[#DDD0B8] rounded-3xl shadow-2xl hidden opacity-0 transition-all duration-300 z-50 p-6 sm:p-8 text-center space-y-5">
        <div class="mx-auto w-12 h-12 rounded-2xl bg-[#E8DCC4] border border-[#DDD0B8] flex items-center justify-center text-xl shadow-xs">
            🔒
        </div>
        <div class="space-y-1.5">
            <span class="text-[11px] font-bold tracking-widest text-[#8C5D37] uppercase">FALK PREMIUM</span>
            <h2 id="paywall-title" class="text-2xl font-black text-[#2D2721] leading-tight">Lås upp hela din kompass</h2>
            <p id="paywall-subtitle" class="text-xs text-stone-600 font-serif italic leading-relaxed max-w-sm mx-auto">
                Du har nått gränsen för gästläget. Skapa ett konto eller logga in för att fortsätta utan begränsningar.
            </p>
        </div>
        <div class="bg-white/80 border border-[#DDD0B8] rounded-2xl p-4 text-left space-y-3 text-xs text-stone-800">
            <div class="flex items-center justify-between pb-2.5 border-b border-[#E6E0D4]">
                <span class="font-bold text-[#8C5D37] text-[11px] uppercase tracking-wider">Erbjudande:</span>
                <span class="bg-[#C57B57] text-white px-3 py-1 rounded-full text-[11px] font-bold shadow-xs">
                    199 kr/mån <span class="line-through opacity-75 font-normal text-[10px] ml-1">ord. 249 kr/mån</span>
                </span>
            </div>
            <div class="flex items-center gap-2.5">
                <span class="text-[#4E5C4B] font-bold text-sm">✓</span>
                <span class="font-medium">Obegränsad chatt, fördjupade perspektiv</span>
            </div>
            <div class="flex items-center gap-2.5">
                <span class="text-[#4E5C4B] font-bold text-sm">✓</span>
                <span class="font-medium">Spara insikter & påminnelser</span>
            </div>
            <div class="flex items-center gap-2.5">
                <span class="text-[#4E5C4B] font-bold text-sm">✓</span>
                <span class="font-medium">Full tillgång till Biblioteket</span>
            </div>
            <div class="flex items-center gap-2.5">
                <span class="text-[#4E5C4B] font-bold text-sm">✓</span>
                <span class="font-medium">Min utveckling och fler funktioner</span>
            </div>
        </div>
        <div class="space-y-2.5 pt-1">
            <button onclick="alert('Omdirigerar till kassan...')" class="w-full py-3.5 bg-[#4E5C4B] hover:bg-[#3D493B] text-white text-xs font-bold rounded-full transition-all shadow-md tracking-wider uppercase">
                Skapa konto
            </button>
            <button onclick="alert('Omdirigerar till inloggning...')" class="w-full py-3 bg-[#FAF8F0] hover:bg-[#E8DCC4] text-[#2D2721] border border-[#DDD0B8] text-xs font-bold rounded-full transition-all">
                Redan medlem? Logga in
            </button>
        </div>
        <button onclick="closePaywallModal()" class="text-xs font-semibold text-stone-500 hover:text-black transition-all block mx-auto pt-1">
            Fortsätt titta runt som gäst
        </button>
    </div>

    <script>
        const IS_GUEST = true;

        function setTheme(theme) {
            localStorage.setItem('falk_theme', theme);
            document.body.className = 'theme-' + theme + ' min-h-screen flex flex-col justify-between antialiased relative overflow-x-hidden';
        }

        window.openPaywallModal = function(reason = 'general') {
            const titleEl = document.getElementById('paywall-title');
            const subEl = document.getElementById('paywall-subtitle');
            
            if (subEl) subEl.innerText = 'Du har nått gränsen för gästläget. Skapa ett konto eller logga in för att fortsätta utan begränsningar.';

            if (reason === 'export') {
                if (titleEl) titleEl.innerText = 'Lås upp Dataexport';
            } else if (reason === 'right_menu') {
                if (titleEl) titleEl.innerText = 'Lås upp Insikter & Påminnelser';
            } else if (reason === 'bibliotek') {
                if (titleEl) titleEl.innerText = 'Lås upp hela Biblioteket';
            } else if (reason === 'utveckling') {
                if (titleEl) titleEl.innerText = 'Lås upp Min Utveckling';
            }

            const bd = document.getElementById("falk-paywall-backdrop");
            const md = document.getElementById("falk-paywall-modal");
            if (bd && md) {
                bd.classList.remove("hidden");
                md.classList.remove("hidden");
                requestAnimationFrame(() => {
                    bd.classList.remove("opacity-0");
                    md.classList.remove("opacity-0");
                });
            }
        };

        window.closePaywallModal = function() {
            const bd = document.getElementById("falk-paywall-backdrop");
            const md = document.getElementById("falk-paywall-modal");
            if (bd && md) {
                bd.classList.add("opacity-0");
                md.classList.add("opacity-0");
                setTimeout(() => {
                    bd.classList.add("hidden");
                    md.classList.add("hidden");
                }, 300);
            }
        };

        function openLeftMenu() { document.getElementById("falk-left-drawer").classList.remove("-translate-x-full"); document.getElementById("falk-left-backdrop").classList.remove("hidden"); setTimeout(() => document.getElementById("falk-left-backdrop").classList.remove("opacity-0"), 10); }
        function closeLeftMenu() { document.getElementById("falk-left-drawer").classList.add("-translate-x-full"); document.getElementById("falk-left-backdrop").classList.add("opacity-0"); setTimeout(() => document.getElementById("falk-left-backdrop").classList.add("hidden"), 300); }
        function openRightMenu() { document.getElementById("falk-right-drawer").classList.remove("translate-x-full"); document.getElementById("falk-right-backdrop").classList.remove("hidden"); setTimeout(() => document.getElementById("falk-right-backdrop").classList.remove("opacity-0"), 10); }
        function closeRightMenu() { document.getElementById("falk-right-drawer").classList.add("translate-x-full"); document.getElementById("falk-right-backdrop").classList.add("opacity-0"); setTimeout(() => document.getElementById("falk-right-backdrop").classList.add("hidden"), 300); }
    </script>
</body>
</html>
'''

with open('templates/installningar.html', 'w', encoding='utf-8') as f:
    f.write(installningar_html)

print("-> [SUCCESS] installningar.html är helt omstrukturerad utan statisk botten-paywall!")
